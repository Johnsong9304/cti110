user_name = input()

# print the welcome message with name

print("Hello",user_name,"and welcome to CS Online!")